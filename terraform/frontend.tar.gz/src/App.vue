<script setup lang="ts">
import { RouterLink, RouterView } from 'vue-router'
import Header from '@/components/layouts/Header.vue'

</script>

<template>
  <Header />
  <RouterView />
</template>

<style scoped></style>
