import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import CompaniesView from '../views/CompaniesView.vue'
import CompanyDetailsView from '../views/CompanyDetailsView.vue'
import HotCompaniesView from '@/views/HotCompaniesView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView
    },
    {
      path: '/companies',
      name: 'companies',
      component: CompaniesView
    },
    {
      path: '/companies/:ticker',
      name: 'company-details',
      component: CompanyDetailsView,
      props: true
    },
    {
      path: '/hot',
      name: 'hot companies',
      component: HotCompaniesView,
      props: true
    },
    {
      path: '/about',
      name: 'about',
      // route level code-splitting
      // this generates a separate chunk (About.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () => import('../views/AboutView.vue')
    }
  ]
})

export default router
